import { Injectable } from '@angular/core';

@Injectable()
export class DepBService {

    constructor() { }
}