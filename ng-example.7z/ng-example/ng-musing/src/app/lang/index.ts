export * from './lang-en';
export * from './lang-es';
export * from './lang-zh';