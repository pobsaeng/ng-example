export * from './page-three-ways.component';
export * from './blogger.component';
export * from './posts-1.component';
export * from './posts-2.component';
export * from './posts-3.component';