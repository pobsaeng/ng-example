export * from './my-pagination.component';
export * from './simple-pagination.component';
export * from './page-component-inheritance.component';