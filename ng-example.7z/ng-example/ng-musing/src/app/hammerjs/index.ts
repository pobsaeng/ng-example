export * from './hammer-config';
export * from './page-hammerjs.component';