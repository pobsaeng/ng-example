export interface Article {
  name: string;
  url: string;
  desc: string;
}