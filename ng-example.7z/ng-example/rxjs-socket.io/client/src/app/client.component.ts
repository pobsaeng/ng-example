import { Component } from '@angular/core';

@Component({
  selector: 'client-app',
  templateUrl: './client.component.html'
})
export class ClientAppComponent {
}
