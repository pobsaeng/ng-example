﻿export * from './product-list.component';
export * from './product-add-edit.component';