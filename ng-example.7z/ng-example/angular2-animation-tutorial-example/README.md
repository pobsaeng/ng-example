# angular2-animation-tutorial-example

Angular 2/4 - Router Animation Example & Tutorial

To see a demo and further details go to http://jasonwatmore.com/post/2017/04/19/angular-2-4-router-animation-tutorial-example