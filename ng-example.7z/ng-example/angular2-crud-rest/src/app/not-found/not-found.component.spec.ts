/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { NotFoundComponent } from './not-found.component';

describe('Component: NotFound', () => {
  it('should create an instance', () => {
    let component = new NotFoundComponent();
    expect(component).toBeTruthy();
  });
});
