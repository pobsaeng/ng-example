/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserFormComponent } from './user-form.component';

describe('Component: UserForm', () => {
  it('should create an instance', () => {
    let component = new UserFormComponent();
    expect(component).toBeTruthy();
  });
});
