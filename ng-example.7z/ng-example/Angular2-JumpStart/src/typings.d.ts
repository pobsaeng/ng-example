/// <reference path="../typings/browser/ambient/es6-shim/index.d.ts" />

declare var module: {id: string};