"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./customer.component'));
__export(require('./customerDetails.component'));
__export(require('./customerOrders.component'));
__export(require('./customerEdit.component'));
//# sourceMappingURL=index.js.map