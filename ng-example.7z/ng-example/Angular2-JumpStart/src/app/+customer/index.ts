export * from './customer.component';
export * from './customerDetails.component';
export * from './customerOrders.component';
export * from './customerEdit.component';